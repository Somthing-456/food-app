﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FoodApp
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void Skip_Button_Click(object sender, EventArgs e)
        {
            var form3 = Application.OpenForms.OfType<Form3>().Single();
            form3.skip();
            this.Close();
            
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            var form3 = Application.OpenForms.OfType<Form3>().Single();
            textBox1.Text = form3.getChosen();
        }
    }
}
