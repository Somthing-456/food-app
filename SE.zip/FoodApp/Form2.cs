﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace FoodApp
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        
        private void CreateAccount_Button_Click(object sender, EventArgs e)
        {
            var form1 = Application.OpenForms.OfType<Form1>().Single();
            if (Password_TextBox.Text == ConfirmPassword_TextBox.Text && Password_TextBox.Text != "") 
            {
                OleDbConnection connection = new OleDbConnection();
                connection.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + form1.getPath() + ";" +
                    "Persist Security Info=False;";
                connection.Open();
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;
                command.CommandText = "select * from LoginData where UserName='" + UserName_TextBox.Text+ "'";
                OleDbDataReader read = command.ExecuteReader();
                int count = 0;
                while (read.Read())
                {
                    count++;
                }
                if (count < 1)
                {
                    connection.Close();
                    connection.Open();
                    OleDbCommand command2 = new OleDbCommand();
                    command2.Connection = connection;
                    command2.CommandText = "Insert into LoginData (UserName,[Password],StoredRestaurants) values('" + UserName_TextBox.Text + "','" + Password_TextBox.Text + "','Sonic')";
                    command2.ExecuteNonQuery();
                    MessageBox.Show("Account has been created!");
                    
                    
                }
                if (count ==1)
                {
                    MessageBox.Show("User name is already taken.");
                }
                connection.Close();
                UserName_TextBox.Text = "";
                ConfirmPassword_TextBox.Text = "";
                Password_TextBox.Text = "";
            }
            else if(Password_TextBox.Text != ConfirmPassword_TextBox.Text)
            {
                MessageBox.Show("Passwords do not Match");
                UserName_TextBox.Text = "";
                ConfirmPassword_TextBox.Text = "";
                Password_TextBox.Text = "";
            }
        }

        private void BackToLogin_button_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
