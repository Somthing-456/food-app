﻿namespace FoodApp
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AddToList_button = new System.Windows.Forms.Button();
            this.Generate_button = new System.Windows.Forms.Button();
            this.GPS_button = new System.Windows.Forms.Button();
            this.LogOut_button = new System.Windows.Forms.Button();
            this.SetChoices_button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // AddToList_button
            // 
            this.AddToList_button.Location = new System.Drawing.Point(106, 31);
            this.AddToList_button.Name = "AddToList_button";
            this.AddToList_button.Size = new System.Drawing.Size(180, 66);
            this.AddToList_button.TabIndex = 0;
            this.AddToList_button.Text = "Add To Your List";
            this.AddToList_button.UseVisualStyleBackColor = true;
            this.AddToList_button.Click += new System.EventHandler(this.AddToList_button_Click);
            // 
            // Generate_button
            // 
            this.Generate_button.Location = new System.Drawing.Point(106, 103);
            this.Generate_button.Name = "Generate_button";
            this.Generate_button.Size = new System.Drawing.Size(180, 66);
            this.Generate_button.TabIndex = 1;
            this.Generate_button.Text = "Generate a Place to Eat From Your List";
            this.Generate_button.UseVisualStyleBackColor = true;
            this.Generate_button.Click += new System.EventHandler(this.Generate_button_Click);
            // 
            // GPS_button
            // 
            this.GPS_button.Location = new System.Drawing.Point(106, 175);
            this.GPS_button.Name = "GPS_button";
            this.GPS_button.Size = new System.Drawing.Size(180, 66);
            this.GPS_button.TabIndex = 2;
            this.GPS_button.Text = "Search for Places";
            this.GPS_button.UseVisualStyleBackColor = true;
            this.GPS_button.Click += new System.EventHandler(this.GPS_button_Click);
            // 
            // LogOut_button
            // 
            this.LogOut_button.Location = new System.Drawing.Point(161, 364);
            this.LogOut_button.Name = "LogOut_button";
            this.LogOut_button.Size = new System.Drawing.Size(74, 37);
            this.LogOut_button.TabIndex = 3;
            this.LogOut_button.Text = "Log Out";
            this.LogOut_button.UseVisualStyleBackColor = true;
            this.LogOut_button.Click += new System.EventHandler(this.LogOut_button_Click);
            // 
            // SetChoices_button
            // 
            this.SetChoices_button.Location = new System.Drawing.Point(106, 247);
            this.SetChoices_button.Name = "SetChoices_button";
            this.SetChoices_button.Size = new System.Drawing.Size(180, 66);
            this.SetChoices_button.TabIndex = 4;
            this.SetChoices_button.Text = "Food By Category";
            this.SetChoices_button.UseVisualStyleBackColor = true;
            this.SetChoices_button.Click += new System.EventHandler(this.SetChoices_button_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(402, 413);
            this.Controls.Add(this.SetChoices_button);
            this.Controls.Add(this.LogOut_button);
            this.Controls.Add(this.GPS_button);
            this.Controls.Add(this.Generate_button);
            this.Controls.Add(this.AddToList_button);
            this.Name = "Form3";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Options";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button AddToList_button;
        private System.Windows.Forms.Button Generate_button;
        private System.Windows.Forms.Button GPS_button;
        private System.Windows.Forms.Button LogOut_button;
        private System.Windows.Forms.Button SetChoices_button;
    }
}