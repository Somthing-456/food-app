﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;

namespace FoodApp
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }
        String path, userName, password;
        OpenFileDialog ofd = new OpenFileDialog();
        public string getPath()
        {
            return path;
        }
        public string getPassword()
        {
            return password;
        }
        public string getUserName()
        {
            return userName;
        }


        private void Login_button_Click(object sender, EventArgs e)
        {
            password = Password_TextBox.Text;
            userName = UserName_TextBox.Text;
            OleDbConnection connection = new OleDbConnection();
            connection.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source="+path+";" +
                "Persist Security Info=False;";
            connection.Open();
            OleDbCommand command = new OleDbCommand();
            command.Connection = connection;
            command.CommandText = "select * from LoginData where UserName='"+UserName_TextBox.Text+"' and Password='"+Password_TextBox.Text+"'";
            OleDbDataReader read = command.ExecuteReader();
            int count = 0;
            while (read.Read())
            {
                count++;
            }
            if(count == 1)
            {
                MessageBox.Show("Login Successful!");
                this.Hide();
                Form3 frm3 = new Form3();
                frm3.ShowDialog();
                frm3 = null;
                this.Show();
            }
            if (count < 1)
            {
                MessageBox.Show("User name or password incorrect");
            }
            UserName_TextBox.Text = "";
            Password_TextBox.Text = "";
            connection.Close();

        }



        private void NewUser_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 frm2 = new Form2();
            frm2.ShowDialog();
            this.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ofd.ShowDialog();
            path = ofd.FileName;
        }
    }
}
