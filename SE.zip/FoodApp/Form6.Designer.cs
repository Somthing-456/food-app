﻿namespace FoodApp
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.southern_button = new System.Windows.Forms.Button();
            this.mexican_button = new System.Windows.Forms.Button();
            this.itialianFood_button = new System.Windows.Forms.Button();
            this.seaFood_button = new System.Windows.Forms.Button();
            this.fastFood_button = new System.Windows.Forms.Button();
            this.asian_button = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // southern_button
            // 
            this.southern_button.Location = new System.Drawing.Point(303, 130);
            this.southern_button.Name = "southern_button";
            this.southern_button.Size = new System.Drawing.Size(136, 43);
            this.southern_button.TabIndex = 0;
            this.southern_button.Text = "Southern Food";
            this.southern_button.UseVisualStyleBackColor = true;
            this.southern_button.Click += new System.EventHandler(this.southern_button_Click);
            // 
            // mexican_button
            // 
            this.mexican_button.Location = new System.Drawing.Point(303, 81);
            this.mexican_button.Name = "mexican_button";
            this.mexican_button.Size = new System.Drawing.Size(136, 43);
            this.mexican_button.TabIndex = 1;
            this.mexican_button.Text = "Mexican";
            this.mexican_button.UseVisualStyleBackColor = true;
            this.mexican_button.Click += new System.EventHandler(this.mexican_button_Click);
            // 
            // itialianFood_button
            // 
            this.itialianFood_button.Location = new System.Drawing.Point(161, 130);
            this.itialianFood_button.Name = "itialianFood_button";
            this.itialianFood_button.Size = new System.Drawing.Size(136, 43);
            this.itialianFood_button.TabIndex = 2;
            this.itialianFood_button.Text = "Italian Food";
            this.itialianFood_button.UseVisualStyleBackColor = true;
            this.itialianFood_button.Click += new System.EventHandler(this.itialianFood_button_Click);
            // 
            // seaFood_button
            // 
            this.seaFood_button.Location = new System.Drawing.Point(19, 130);
            this.seaFood_button.Name = "seaFood_button";
            this.seaFood_button.Size = new System.Drawing.Size(136, 43);
            this.seaFood_button.TabIndex = 3;
            this.seaFood_button.Text = "Sea Food";
            this.seaFood_button.UseVisualStyleBackColor = true;
            this.seaFood_button.Click += new System.EventHandler(this.seaFood_button_Click);
            // 
            // fastFood_button
            // 
            this.fastFood_button.Location = new System.Drawing.Point(161, 81);
            this.fastFood_button.Name = "fastFood_button";
            this.fastFood_button.Size = new System.Drawing.Size(136, 43);
            this.fastFood_button.TabIndex = 4;
            this.fastFood_button.Text = "Fast Food";
            this.fastFood_button.UseVisualStyleBackColor = true;
            this.fastFood_button.Click += new System.EventHandler(this.fastFood_button_Click);
            // 
            // asian_button
            // 
            this.asian_button.Location = new System.Drawing.Point(19, 81);
            this.asian_button.Name = "asian_button";
            this.asian_button.Size = new System.Drawing.Size(136, 44);
            this.asian_button.TabIndex = 5;
            this.asian_button.Text = "Asian";
            this.asian_button.UseVisualStyleBackColor = true;
            this.asian_button.Click += new System.EventHandler(this.asian_button_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(91, 33);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(274, 22);
            this.textBox1.TabIndex = 6;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Form6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(464, 194);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.asian_button);
            this.Controls.Add(this.fastFood_button);
            this.Controls.Add(this.seaFood_button);
            this.Controls.Add(this.itialianFood_button);
            this.Controls.Add(this.mexican_button);
            this.Controls.Add(this.southern_button);
            this.Name = "Form6";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Categories";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button southern_button;
        private System.Windows.Forms.Button mexican_button;
        private System.Windows.Forms.Button itialianFood_button;
        private System.Windows.Forms.Button seaFood_button;
        private System.Windows.Forms.Button fastFood_button;
        private System.Windows.Forms.Button asian_button;
        private System.Windows.Forms.TextBox textBox1;
    }
}