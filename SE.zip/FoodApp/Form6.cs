﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FoodApp
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void asian_button_Click(object sender, EventArgs e)
        {
            string asian = "Ultra-Violet by Paul Pairet,The Eight,Jade Dragon,Jungsik,Waku Ghin,Burnt Ends";
            string[] food = asian.Split(',');
            Random rnd = new Random();
            int number = rnd.Next(food.Length);
            textBox1.Text = food[number];

        }

        private void fastFood_button_Click(object sender, EventArgs e)
        {
            string fast = "McDonald's,Burger King,Wendy's,Sonic,KFC,Chick-fil-A,Subway";
            string[] food = fast.Split(',');
            Random rnd = new Random();
            int number = rnd.Next(food.Length);
            textBox1.Text = food[number];
        }

        private void seaFood_button_Click(object sender, EventArgs e)
        {
            string Sea = "Real Catches,Cobalt,Bridge Seafood,Mariscos Chihuahua,Powerhouse Seafood & Grill";
            string[] food = Sea.Split(',');
            Random rnd = new Random();
            int number = rnd.Next(food.Length);
            textBox1.Text = food[number];
        }

        private void itialianFood_button_Click(object sender, EventArgs e)
        {
            string italian = "La Griglia,Pizza Birra Vino,Grotto Ristorante,North Italia,Prego Italian Cuisine";
            string[] food = italian.Split(',');
            Random rnd = new Random();
            int number = rnd.Next(food.Length);
            textBox1.Text = food[number];

        }

        private void southern_button_Click(object sender, EventArgs e)
        {
            string southern = "Abel Brown,Alligator Soul,The Boil Waverly,Cured,Dogwood: A Southern Table,Highball & Harvest";
            string[] food = southern.Split(',');
            Random rnd = new Random();
            int number = rnd.Next(food.Length);
            textBox1.Text = food[number];
        }

        private void mexican_button_Click(object sender, EventArgs e)
        {
            string mexican = "Avila's Mexican Food,Barrio Café,Birrieria Zaragoza,Broken Spanish,Cala";
            string[] food = mexican.Split(',');
            Random rnd = new Random();
            int number = rnd.Next(food.Length);
            textBox1.Text = food[number];
        }
    }
}
