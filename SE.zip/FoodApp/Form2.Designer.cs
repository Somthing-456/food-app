﻿namespace FoodApp
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Welcome_label = new System.Windows.Forms.Label();
            this.CreateUserName_label = new System.Windows.Forms.Label();
            this.CreatePassword_label = new System.Windows.Forms.Label();
            this.CreateAccount_Button = new System.Windows.Forms.Button();
            this.BackToLogin_button = new System.Windows.Forms.Button();
            this.UserName_TextBox = new System.Windows.Forms.TextBox();
            this.Password_TextBox = new System.Windows.Forms.TextBox();
            this.CreateAccount_label = new System.Windows.Forms.Label();
            this.ConfirmPassword_TextBox = new System.Windows.Forms.TextBox();
            this.ConfirmPassword_label = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Welcome_label
            // 
            this.Welcome_label.AutoSize = true;
            this.Welcome_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Welcome_label.Location = new System.Drawing.Point(84, 78);
            this.Welcome_label.Name = "Welcome_label";
            this.Welcome_label.Size = new System.Drawing.Size(234, 58);
            this.Welcome_label.TabIndex = 0;
            this.Welcome_label.Text = "Welcome";
            // 
            // CreateUserName_label
            // 
            this.CreateUserName_label.AutoSize = true;
            this.CreateUserName_label.Location = new System.Drawing.Point(65, 242);
            this.CreateUserName_label.Name = "CreateUserName_label";
            this.CreateUserName_label.Size = new System.Drawing.Size(79, 17);
            this.CreateUserName_label.TabIndex = 1;
            this.CreateUserName_label.Text = "User Name";
            // 
            // CreatePassword_label
            // 
            this.CreatePassword_label.AutoSize = true;
            this.CreatePassword_label.Location = new System.Drawing.Point(65, 272);
            this.CreatePassword_label.Name = "CreatePassword_label";
            this.CreatePassword_label.Size = new System.Drawing.Size(69, 17);
            this.CreatePassword_label.TabIndex = 2;
            this.CreatePassword_label.Text = "Password";
            // 
            // CreateAccount_Button
            // 
            this.CreateAccount_Button.Location = new System.Drawing.Point(132, 327);
            this.CreateAccount_Button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.CreateAccount_Button.Name = "CreateAccount_Button";
            this.CreateAccount_Button.Size = new System.Drawing.Size(147, 37);
            this.CreateAccount_Button.TabIndex = 3;
            this.CreateAccount_Button.Text = "Create Account";
            this.CreateAccount_Button.UseVisualStyleBackColor = true;
            this.CreateAccount_Button.Click += new System.EventHandler(this.CreateAccount_Button_Click);
            // 
            // BackToLogin_button
            // 
            this.BackToLogin_button.Location = new System.Drawing.Point(132, 370);
            this.BackToLogin_button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BackToLogin_button.Name = "BackToLogin_button";
            this.BackToLogin_button.Size = new System.Drawing.Size(147, 30);
            this.BackToLogin_button.TabIndex = 4;
            this.BackToLogin_button.Text = "Back to Login";
            this.BackToLogin_button.UseVisualStyleBackColor = true;
            this.BackToLogin_button.Click += new System.EventHandler(this.BackToLogin_button_Click);
            // 
            // UserName_TextBox
            // 
            this.UserName_TextBox.Location = new System.Drawing.Point(204, 239);
            this.UserName_TextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.UserName_TextBox.Name = "UserName_TextBox";
            this.UserName_TextBox.Size = new System.Drawing.Size(145, 22);
            this.UserName_TextBox.TabIndex = 5;
            // 
            // Password_TextBox
            // 
            this.Password_TextBox.Location = new System.Drawing.Point(204, 272);
            this.Password_TextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Password_TextBox.Name = "Password_TextBox";
            this.Password_TextBox.Size = new System.Drawing.Size(145, 22);
            this.Password_TextBox.TabIndex = 6;
            // 
            // CreateAccount_label
            // 
            this.CreateAccount_label.AutoSize = true;
            this.CreateAccount_label.Location = new System.Drawing.Point(3, 192);
            this.CreateAccount_label.Name = "CreateAccount_label";
            this.CreateAccount_label.Size = new System.Drawing.Size(397, 17);
            this.CreateAccount_label.TabIndex = 7;
            this.CreateAccount_label.Text = "Please enter a user name and password to create an account";
            // 
            // ConfirmPassword_TextBox
            // 
            this.ConfirmPassword_TextBox.Location = new System.Drawing.Point(204, 302);
            this.ConfirmPassword_TextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ConfirmPassword_TextBox.Name = "ConfirmPassword_TextBox";
            this.ConfirmPassword_TextBox.Size = new System.Drawing.Size(145, 22);
            this.ConfirmPassword_TextBox.TabIndex = 8;
            // 
            // ConfirmPassword_label
            // 
            this.ConfirmPassword_label.AutoSize = true;
            this.ConfirmPassword_label.Location = new System.Drawing.Point(65, 302);
            this.ConfirmPassword_label.Name = "ConfirmPassword_label";
            this.ConfirmPassword_label.Size = new System.Drawing.Size(121, 17);
            this.ConfirmPassword_label.TabIndex = 9;
            this.ConfirmPassword_label.Text = "Confirm Password";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(403, 414);
            this.Controls.Add(this.ConfirmPassword_label);
            this.Controls.Add(this.ConfirmPassword_TextBox);
            this.Controls.Add(this.CreateAccount_label);
            this.Controls.Add(this.Password_TextBox);
            this.Controls.Add(this.UserName_TextBox);
            this.Controls.Add(this.BackToLogin_button);
            this.Controls.Add(this.CreateAccount_Button);
            this.Controls.Add(this.CreatePassword_label);
            this.Controls.Add(this.CreateUserName_label);
            this.Controls.Add(this.Welcome_label);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form2";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "New User";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Welcome_label;
        private System.Windows.Forms.Label CreateUserName_label;
        private System.Windows.Forms.Label CreatePassword_label;
        private System.Windows.Forms.Button CreateAccount_Button;
        private System.Windows.Forms.Button BackToLogin_button;
        private System.Windows.Forms.TextBox UserName_TextBox;
        private System.Windows.Forms.TextBox Password_TextBox;
        private System.Windows.Forms.Label CreateAccount_label;
        private System.Windows.Forms.TextBox ConfirmPassword_TextBox;
        private System.Windows.Forms.Label ConfirmPassword_label;
    }
}