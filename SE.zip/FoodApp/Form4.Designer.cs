﻿namespace FoodApp
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AddFood_button = new System.Windows.Forms.Button();
            this.Food_TextBox = new System.Windows.Forms.TextBox();
            this.Food_label = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // AddFood_button
            // 
            this.AddFood_button.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.AddFood_button.Location = new System.Drawing.Point(101, 103);
            this.AddFood_button.Name = "AddFood_button";
            this.AddFood_button.Size = new System.Drawing.Size(104, 43);
            this.AddFood_button.TabIndex = 0;
            this.AddFood_button.Text = "Add";
            this.AddFood_button.UseVisualStyleBackColor = true;
            // 
            // Food_TextBox
            // 
            this.Food_TextBox.Location = new System.Drawing.Point(72, 62);
            this.Food_TextBox.Name = "Food_TextBox";
            this.Food_TextBox.Size = new System.Drawing.Size(165, 22);
            this.Food_TextBox.TabIndex = 1;
            // 
            // Food_label
            // 
            this.Food_label.AutoSize = true;
            this.Food_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Food_label.Location = new System.Drawing.Point(67, 22);
            this.Food_label.Name = "Food_label";
            this.Food_label.Size = new System.Drawing.Size(179, 25);
            this.Food_label.TabIndex = 2;
            this.Food_label.Text = "Enter a place to eat";
            // 
            // Form4
            // 
            this.AcceptButton = this.AddFood_button;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(309, 158);
            this.Controls.Add(this.Food_label);
            this.Controls.Add(this.Food_TextBox);
            this.Controls.Add(this.AddFood_button);
            this.Name = "Form4";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Options";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button AddFood_button;
        private System.Windows.Forms.TextBox Food_TextBox;
        private System.Windows.Forms.Label Food_label;
    }
}