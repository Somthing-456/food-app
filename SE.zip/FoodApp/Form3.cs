﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace FoodApp
{
    public partial class Form3 : Form
    {
        string add;
        public Form3()
        {
            InitializeComponent();
        }
        public string getChosen()
        {
            
            return chosenFood;
        }
        public void skip()
        {
            Generate_button.PerformClick();
            
        }
        string food, chosenFood;
        string[] randomfood;
        private void AddToList_button_Click(object sender, EventArgs e)
        {
            using (Form4 frm = new Form4())
            {
                if (frm.ShowDialog() == DialogResult.OK)
                    add = frm.getValue();
            }
            var form1 = Application.OpenForms.OfType<Form1>().Single();
            OleDbConnection connection = new OleDbConnection();
            connection.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + form1.getPath() + ";" +
                "Persist Security Info=False;";
            connection.Open();
            
            
            food = food + "," + add;
            

            OleDbCommand command = new OleDbCommand();
            command.Connection = connection;
            command.CommandText = "update LoginData set StoredRestaurants='"+food+"' where UserName = '"+form1.getUserName()+"'";
            command.ExecuteNonQuery();
        }

        private void Generate_button_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            randomfood = food.Split(',');
            int number = rnd.Next(randomfood.Length);
            chosenFood = randomfood[number];
            Form5 frm5 = new Form5();
            frm5.ShowDialog();
        }

        private void LogOut_button_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void SetChoices_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form6 frm6 = new Form6();
            frm6.ShowDialog();
            this.Show();
        }

        private void GPS_button_Click(object sender, EventArgs e)
        {
            
            Form7 frm7 = new Form7();
            this.Hide();
            frm7.ShowDialog();
            this.Show();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            var form1 = Application.OpenForms.OfType<Form1>().Single();
            OleDbConnection connection = new OleDbConnection();
            connection.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + form1.getPath() + ";" +
                "Persist Security Info=False;";
            connection.Open();
            OleDbCommand command = new OleDbCommand();
            command.Connection = connection;
            command.CommandText = "select * from LoginData where UserName='"+ form1.getUserName() +"'";
            OleDbDataReader read = command.ExecuteReader();
            if (read.Read())
            {
                
             food = read.GetString(4);
                
            }
            else
            {
                
            }
        }
    }
}
